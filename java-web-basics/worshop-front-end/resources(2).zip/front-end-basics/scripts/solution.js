function solve() {
   
}
